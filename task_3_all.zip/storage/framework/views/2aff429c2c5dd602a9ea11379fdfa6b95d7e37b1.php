<?php $__env->startSection('title-block'); ?>Курсы<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <ul>
                <li><?php echo e($error); ?></li>
            </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    <?php endif; ?>

    <form action="<?php echo e(route('form-cur')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label>Ввод</label>
        <input name="count"  placeholder="Ввод" class="form-control">

        <select name="cur" class="btn btn-outline-success dropdown-toggle" >
            <option value="byn">byn</option>
            <option value="usd">usd</option>
            <option value="eur">eur</option>
            <option value="rus">rus</option>
        </select>


        <button type="submit" class="btn btn-success m-4"style="width:145px;">Курс</button>

            <?php
            if(isset($retArr)){

            foreach ($retArr as $key=>$value){
            ?>
            <label><?php echo $key; ?></label>
            <input name="<?php echo $key; ?>" value="<?php echo $value; ?>" placeholder="<?php echo $key; ?>" class="form-control"><br>
            <?php
            }
            }
            ?>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('aside'); ?>
    <p>Текст из show</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\task\resources\views//res.blade.php ENDPATH**/ ?>