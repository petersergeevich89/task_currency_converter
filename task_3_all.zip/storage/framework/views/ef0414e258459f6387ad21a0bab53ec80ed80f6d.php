<?php $__env->startSection('title-block'); ?>Регистрация пользователя <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Validation Errors -->
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <form method="POST" action="<?php echo e(route('register')); ?>">
    <?php echo csrf_field(); ?>

    <!-- Name -->
        <div>
            <label>Имя</label>
            <input id="name" class="form-control" type="text" name="name" :value="old('name')" required autofocus />
        </div>

        <!-- Email Address -->
        <div>
            <label> Email</label>

            <input id="email" class="form-control" type="email" name="email" :value="old('email')" required />
        </div>

        <!-- Password -->
        <div >
            <label>Пароль</label>

            <input id="password" class="form-control"
                   type="password"
                   name="password"
                   required autocomplete="new-password" />
        </div>

        <!-- Confirm Password -->
        <div >
            <label>Пароль еще раз</label>

            <input id="password_confirmation" class="form-control"
                   type="password"
                   name="password_confirmation" required />
        </div>

        <div >

            <button class="btn btn-success mt-4">
                <?php echo e(__('Регистрация')); ?>

            </button>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\localhost\task3\resources\views/auth/register.blade.php ENDPATH**/ ?>