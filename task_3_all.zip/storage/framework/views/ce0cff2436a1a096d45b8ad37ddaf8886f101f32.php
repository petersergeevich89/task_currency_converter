<?php echo e($slot); ?>

<?php /**PATH C:\OpenServer\domains\task\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>