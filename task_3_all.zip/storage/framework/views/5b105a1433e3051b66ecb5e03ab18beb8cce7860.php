<div id='myheader' class="d-flex flex-column flex-md-row align-items-center pb-3 mb-4 border-bottom">
    <a href="/" class="d-flex align-items-center text-dark text-decoration-none">

        <span class="fs-4"><?php echo $__env->yieldContent('title-block'); ?></span>
    </a>

    <nav class="d-inline-flex mt-2 mt-md-0 ms-md-auto">
        <?php if(Auth::user()): ?>
            <a class="me-3 py-2 text-dark text-decoration-none" href=" <?php echo e(route('form-cur')); ?>">Курсы валют</a>
            <a class="me-3 py-2 text-dark text-decoration-none" href="<?php echo e(route('form-edit')); ?>">Информация</a>
            <a class="me-3 py-2 text-dark text-decoration-none" href="<?php echo e(route('form-update')); ?>">Редактирова</a>
            <a class="me-3 py-2 text-dark text-decoration-none" href="<?php echo e(route('logout')); ?>">Выход</a>
        <?php else: ?>
            <a class="me-3 py-2 text-dark text-decoration-none" href="<?php echo e(route('login')); ?>">Войти</a>
            <a class="me-3 py-2 text-dark text-decoration-none" href="<?php echo e(route('register')); ?>">Регистрация</a>
        <?php endif; ?>

    </nav>
</div>
<?php /**PATH E:\OpenServer\domains\localhost\task3\resources\views/inc/header.blade.php ENDPATH**/ ?>