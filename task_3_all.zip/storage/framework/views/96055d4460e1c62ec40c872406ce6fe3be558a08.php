<?php $__env->startSection('title-block'); ?>История<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p><label>Имя пользователя: </label>
    <?php echo e($info['user']->name); ?></p>
    <p><label>Почта: </label>
    <?php echo e($info['user']->email); ?></p>


    <?php $__currentLoopData = $info['history']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p>Валюта поиска <?php echo e($history->cur_enter); ?>.<br>
            byn: <?php echo e($history->byn); ?>,<br>
            usd: <?php echo e($history->usd); ?>,<br>
            eur: <?php echo e($history->eur); ?>,<br>
            rus: <?php echo e($history->rus); ?> <br>
            дата: <?php echo e($history->created_at); ?><br>

            <a href="<?php echo e(route('form-cur-delete',['id'=>$history->id ])); ?>">Удалить</a></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\localhost\task3\resources\views/edit.blade.php ENDPATH**/ ?>