

    <?php if(Route::has('login')): ?>
        <div >
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(url('/dashboard')); ?>" >Dashboard</a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" >Log in</a>

                <?php if(Route::has('register')): ?>
                    <a href="<?php echo e(route('register')); ?>" >Register</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>


<?php /**PATH C:\OpenServer\domains\task\resources\views/home.blade.php ENDPATH**/ ?>