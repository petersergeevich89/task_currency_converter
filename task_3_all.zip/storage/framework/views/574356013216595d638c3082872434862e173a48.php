<?php $__env->startSection('aside'); ?>

<div class="asside">
    <h4>Боковая панель</h4>
<p>
Текст боковой панели
</p>
    <?php echo $__env->yieldSection(); ?>
</div>
<?php /**PATH C:\OpenServer\domains\task\resources\views/inc/aside.blade.php ENDPATH**/ ?>