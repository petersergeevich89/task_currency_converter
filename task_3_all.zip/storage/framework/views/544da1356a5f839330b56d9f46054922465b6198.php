<?php $__env->startSection('title-block'); ?>Редкатировать <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ul>
                    <li><?php echo e($error); ?></li>
                </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    <?php endif; ?>


    <form action="<?php echo e(route('form-update-add')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label >Имя пользователя</label>
        <input type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control">
        <label>Почта</label>
        <input type="text" name="email" value="<?php echo e($user->email); ?>" class="form-control">

        <br>
        <button type="submit" class="btn btn-success">Обновить</button>

    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\task\resources\views/update.blade.php ENDPATH**/ ?>