[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\OpenServer\domains\task\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>